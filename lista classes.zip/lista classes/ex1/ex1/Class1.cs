﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex1
{
    internal class Cliente
    {
        private string nome;
        private string endereco;
        private string telefone;
        public Cliente() { }

        public Cliente(string nome, string endereco, string telefone)
        {
            this.nome = nome;
            this.endereco = endereco;
            this.telefone = telefone;
        }

        public string _nome
        {
            set { this.nome = value;  }
            get { return this.nome; }
        }
        public string _endereco
        {
            set { this.endereco = value; }
            get { return this.endereco; }
        }
        public string _telefone
        {
            set { this.telefone = value; }
            get { return this.telefone; }
        }
        




    }
}
