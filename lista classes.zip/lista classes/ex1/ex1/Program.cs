﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cliente[] cliente = new Cliente[3];
            for (int i = 0; i < 3; i++)
            {
                cliente[i] = new Cliente();
                Console.WriteLine($"Preencha o Nome, Endereço e Telefone da Cliente {i + 1}");
                cliente[i]._nome = Console.ReadLine();
                cliente[i]._endereco = Console.ReadLine();
                cliente[i]._telefone = Console.ReadLine();
            }
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine(cliente[i]._nome + " " + cliente[i]._endereco + " " + cliente[i]._telefone);
            }

        }
    }
}
