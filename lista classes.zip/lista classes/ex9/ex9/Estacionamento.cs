﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex9
{
    internal class Estacionamento
    {
        private String nome; //nome do estacionamento.
        private int numTotalVagas;//número total de vagas do estacionamento.

        private int numVagasLivres; //número de vagas livres no estacionamento.
        private String[] vagas; // vetor que armazena cada uma das vagas do estacionamento.
                                // Caso a vaga esteja ocupada, este vetor indica a placa do veículo que a ocupa.
        public Estacionamento(String nome, int numTotalVagas)
        {
            this.nome = nome;
            this.numTotalVagas = numTotalVagas;
            vagas = new string[numTotalVagas];
            for (int i = 0; i < vagas.Length; i++)
            {
                vagas[i] = "vazia"; 
            }
        }
        public int Estacionar(String placa)
        {
            for(int i = 0; i < vagas.Length; i++)
            {
                if (vagas[i] == "vazia")
                {
                    vagas[i] = placa;
                    return i;
                }
            }
            return -1;
        }
        public int ObterVagaOcupada(String placa)
        {
            for (int i = 0; i < vagas.Length; i++)
            {
                if (vagas[i] == placa)
                {
                    return i;
                }
            }
            return -1;
        }
        public void RetirarVeiculo(String placa)
        {
            for (int i = 0; i < vagas.Length; i++)
            {
                if (vagas[i] == placa)
                {
                    vagas[i] = "vazia";
                }
            }
        }
        public int ObterNumVagasLivres()
        {
            int contador = 0;
            for (int i = 0; i < vagas.Length; i++)
            {
                if (vagas[i] == "vazia")
                {
                    contador++;
                }
            }
            return contador;
        }
        public void ExibirOcupacao()
        {
            for (int i = 0; i < vagas.Length; i++)
            {
               Console.WriteLine($"{vagas[i]} ");
            }
        }
    }
}
