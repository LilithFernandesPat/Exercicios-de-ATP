﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex3
{
    internal class Circulo
    {
        private double raio;

        public Circulo(double raio)
        {
            this.raio = raio;
        }

        public double CalcularArea()
        {
            double area = Math.PI * (raio * raio);
            return area;
        }

        public double CalcularDiametro()
        {
            double diametro = 2 * raio;
            return diametro;
        }

        public double CalcularPerimetro()
        {
            double perimetro = 2 * Math.PI * raio;
            return perimetro;
        }
    }
}
