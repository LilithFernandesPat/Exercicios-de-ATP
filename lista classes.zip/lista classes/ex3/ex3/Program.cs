﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*Crie uma classe "Circulo" com o campo "raio". Implemente um método construtor e a propriedade.
Adicione os seguintes métodos:
● CalcularArea: método sem parâmetros, que deve calcular e retornar a área do círculo
● CalularDiametro: método sem parâmetros, que deve calcular e retornar o diâmetro do círculo.
● CalcularPerimetro: método sem parâmetros, que deve calcular e retornar o diâmetro do círculo.
Implemente uma classe Teste (com método Main), crie 4 círculos e mostre a utilização de todos os métodos
da classe Circulo.*/

namespace ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double raio;

            Console.WriteLine("insira o valor do raio do Circulo 1");
            raio = double.Parse(Console.ReadLine());
            Circulo circulo1 = new Circulo(raio);
            Console.WriteLine(circulo1.CalcularArea());
            Console.WriteLine(circulo1.CalcularDiametro());
            Console.WriteLine(circulo1.CalcularPerimetro());


            Console.WriteLine("insira o valor do raio do Circulo 2");
            raio = double.Parse(Console.ReadLine());
            Circulo circulo2 = new Circulo(raio);
            Console.WriteLine(circulo2.CalcularArea());
            Console.WriteLine(circulo2.CalcularDiametro());
            Console.WriteLine(circulo2.CalcularPerimetro());


            Console.WriteLine($"insira o valor do raio do Circulo {1}");
            raio = double.Parse(Console.ReadLine());
            Circulo circulo3 = new Circulo(raio);
            Console.WriteLine(circulo3.CalcularArea());
            Console.WriteLine(circulo3.CalcularDiametro());
            Console.WriteLine(circulo3.CalcularPerimetro());


            Console.WriteLine($"insira o valor do raio do Circulo {1}");
            raio = double.Parse(Console.ReadLine());
            Circulo circulo4 = new Circulo(raio);
            Console.WriteLine(circulo4.CalcularArea());
            Console.WriteLine(circulo4.CalcularDiametro());
            Console.WriteLine(circulo4.CalcularPerimetro());


        }
    }
}
