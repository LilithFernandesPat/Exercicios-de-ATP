﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex8
{
    internal class ContaCorrente
    {
        private int numero;
        private int digito;
        private Agencia agencia;
        private double saldo;

        public ContaCorrente(int numero, int digito, Agencia agencia, double saldo)
        {
            this.numero = numero;
            this.digito = digito;
            this.agencia = agencia;
            this.saldo = saldo;
        }

        public void depositar(double valor)
        {
            saldo += valor;
            Console.WriteLine("Deposito realizado");
        }
        public void sacar(double valor)
        {
            if (saldo > valor)
            {
                saldo -= valor;
                Console.WriteLine("saque realizado");
            }
            else { Console.WriteLine("Não tem saldo suficiente"); }
        }

        public string consultarSaldo()
        {
            return $"Conta Corrente: {numero}  {digito}, Agencia: {agencia._numero}  {agencia._digito}. \n Saldo: {saldo}";
        }
    }
}
