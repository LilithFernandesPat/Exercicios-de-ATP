﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex8
{
    internal class Cliente
    {
        private string nome;
        private string cpf;
        private ContaCorrente conta;

        public Cliente(string nome, string cpf, ContaCorrente conta)
        {
            this.nome = nome;
            this.cpf = cpf;
            this.conta = conta;
        }

        public string _nome { set { this.nome = value; } get { return nome; } }
        public string _cpf { set { this.cpf = value; } get { return cpf; } }
        public ContaCorrente _conta { set { this.conta = value; } get { return conta; } }
    }
}
