﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex8
{
    internal class Agencia
    {
        private string nome;
        private int numero;
        private int digito;

        public Agencia(string nome, int numero, int digito)
        {
            this.nome = nome;
            this.numero = numero;
            this.digito = digito;
        }
        public string _nome { set { this.nome = value; } get { return nome; } }
        public int _numero { set { this.numero = value; } get { return numero; } }
        public int _digito { set { this.digito = value; } get { return digito; } }


    }
}
