﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex8
{
    internal class CaixaEletronico
    {
        static void Main(string[] args)
        {
            Agencia agencia = new Agencia("Pampulha", 7890, 5);
            ContaCorrente conta = new ContaCorrente(1234, 4, agencia, 150.00);
            Cliente cliente = new Cliente("Ademar da Silva", "123231518-12", conta);

            cliente._conta.sacar(140);
            Console.WriteLine(cliente._conta.consultarSaldo());
            cliente._conta.sacar(200);
            Console.WriteLine(cliente._conta.consultarSaldo());
            cliente._conta.depositar(25.45);
            Console.WriteLine(cliente._conta.consultarSaldo());


        }
    }
}
