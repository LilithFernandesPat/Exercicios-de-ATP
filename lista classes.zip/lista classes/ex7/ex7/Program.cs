﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex7
{
    internal class TesteProduto
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Informe a marca e o tamanho para a etiqueta");
            string marca = Console.ReadLine();
            string tamanho = Console.ReadLine();
            Etiqueta etiqueta = new Etiqueta(marca, tamanho);
            Console.WriteLine("Informe o Nome e o Preco do produto");
            string nome = Console.ReadLine();
            double preco = double.Parse(Console.ReadLine());
            Produto produto = new Produto(nome, preco, etiqueta);
            Console.WriteLine($"{produto._nome}, {produto._preco}, {produto._etiqueta._marca}, {produto._etiqueta._tamanho}");

            //Segundo metodo

            Console.WriteLine("Informe a marca e o tamanho para a etiqueta");
            marca = Console.ReadLine();
            tamanho = Console.ReadLine();
            Console.WriteLine("Informe o Nome e o Preco do produto");
            nome = Console.ReadLine();
            preco = double.Parse(Console.ReadLine());
            Produto produto1 = new Produto(nome, preco, marca, tamanho);
            Console.WriteLine($"{produto1._nome}, {produto1._preco}, {produto1._etiqueta._marca}, {produto1._etiqueta._tamanho}");
        }
    }
}
