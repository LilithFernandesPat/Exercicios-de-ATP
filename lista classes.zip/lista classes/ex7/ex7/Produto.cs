﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex7
{
    internal class Produto
    {
        private string nome;
        private double preco;
        private Etiqueta etiqueta;

        public Produto(string nome, double preco, Etiqueta etiqueta)
        {
            this.nome = nome;
            this.preco = preco;
            this.etiqueta = etiqueta;
        }
        public Produto(string nome, double preco, string marca, string tamanho)
        {
            this.nome = nome;
            this.preco = preco;
            this.etiqueta = new Etiqueta(marca, tamanho);
        }
        public string _nome { get { return nome; } }
        public double _preco { get { return preco; } }
        public Etiqueta _etiqueta{ get { return etiqueta; } }

    }
}
