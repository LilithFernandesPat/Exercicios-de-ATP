﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex7
{
    internal class Etiqueta
    {
        private string marca;
        private string tamanho;

        public Etiqueta(string marca, string tamanho)
        {
            this.marca = marca;
            this.tamanho = tamanho;
        }
        public string _marca{ get{ return marca;} }
        public string _tamanho { get { return tamanho; } }

    }
}
