﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex6
{
    internal class Funcionario
    {
        private Cargo cargo;
        private char sexo;
        private double horasTrabalhadas;

        public Funcionario(Cargo cargo, char sexo, double horasTrabalhadas)
        {
            this.cargo = cargo;
            this.sexo = sexo;
            this.horasTrabalhadas = horasTrabalhadas;
        }
        public double salarioFinal()
        {
            double salario = cargo._valorHora * horasTrabalhadas;
            return salario;
        }
    }
}
