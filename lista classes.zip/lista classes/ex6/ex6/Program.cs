﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cargo[] cargos = new Cargo[3];
            Funcionario[] funcionarios = new Funcionario[3];

            for (int i = 0; i < cargos.Length; i++)
            {
                Console.WriteLine("Qual o Código do cargo?");
                int codigoCargo = int.Parse(Console.ReadLine());
                Console.WriteLine("Qual o valor da hora deste cargo?");
                double valorHora = double.Parse(Console.ReadLine());
                cargos[i] = new Cargo(codigoCargo, valorHora);
            }

            for (int i = 0; i < funcionarios.Length; i++)
            {
                Console.WriteLine($"Qual o Cargo? 1- {cargos[0]._codigoCargo} 2- {cargos[1]._codigoCargo} 3- {cargos[2]._codigoCargo}");
                int n = int.Parse(Console.ReadLine());
                char sexo = char.Parse(Console.ReadLine());
                double horasTrabalhadas = double.Parse(Console.ReadLine()) ;
                funcionarios[i] = new Funcionario(cargos[n-1], sexo, horasTrabalhadas);
            }

            for (int i = 0; i < funcionarios.Length; i++)
            {
                Console.WriteLine(funcionarios[i].salarioFinal());
            }
        }
    }
}
