﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex6
{
    internal class Cargo
    {
        private int codigoCargo;
        private double valorHora;
        
        public Cargo(int codigoCargo, double valorHora)
        {
            this.codigoCargo = codigoCargo;
            this.valorHora = valorHora;
        }
        public double _valorHora
        {
            get { return valorHora; }
        }
        public int _codigoCargo
        {
            get { return codigoCargo; }
        }
    }
}
