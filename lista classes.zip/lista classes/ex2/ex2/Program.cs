﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o dia");
            int dia = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o mês");
            int mes = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o ano");
            int ano = int.Parse(Console.ReadLine());

            
            Data date = new Data(dia, mes, ano);
            Console.WriteLine(date.toString());

        }
    }
}
