﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex4
{
    internal class Aluno
    {
        private string nome;
        private int matricula;
        private double[] notas = new double[10];

        public string _nome
        {
            set{ this.nome = value;}
            get {return this.nome;}
        }
        public int _matricula
        {
            set { this.matricula = value; }
            get { return this.matricula; }
        }
        public double[] _notas
        {
            set { this.notas = value; }
            get { return this.notas; }
        }
        public double Media()
        {
            double media, soma=0;
            for (int i = 0; i < notas.Length; i++)
            {
                soma += notas[i];
            }
            media = soma / 10;
            return media;
        }
    }
}
