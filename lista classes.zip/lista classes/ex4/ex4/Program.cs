﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Aluno aluno1 = new Aluno();
            Aluno aluno2 = new Aluno();
            double[] notas = new double[10];

            Console.WriteLine("Qual o nome do Aluno 1");
            aluno1._nome = Console.ReadLine();
            Console.WriteLine("Qual a matricula do Aluno 1");
            aluno1._matricula = int.Parse(Console.ReadLine());
            for (int i=0; i<10;i++)
            {
                Console.WriteLine($"Qual a nota {i+1}");
                notas[i] = double.Parse(Console.ReadLine());
                aluno1._notas = notas; 
            }
            Console.WriteLine($"{aluno1.Media()}");

            Console.WriteLine("Qual o nome do Aluno 2");
            aluno2._nome = Console.ReadLine();
            Console.WriteLine("Qual a matricula do Aluno 2");
            aluno2._matricula = int.Parse(Console.ReadLine());
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Qual a nota {i + 1}");
                notas[i] = double.Parse(Console.ReadLine());
                aluno2._notas = notas;
            }
            Console.WriteLine($"{aluno2.Media()}");
        }
    }
}
