﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = "votos.txt";
            string[] candidatos = {"Perna Longa", "Pluto", "Mickey", "Bob Esponja", "Cebolinha"};
            int[] votos = new int[5];
            int votosnulos = 0;
            int menosVotado = 0;
            int maisVotado = 0;
            using (StreamReader sr = new StreamReader(path))
            {
                string s;
                while ((s = sr.ReadLine()) != null)
                {
                    if (int.TryParse(s, out int voto))
                    {
                        if (voto >= 1 && voto < 5)
                        {
                            votos[voto]++;
                        }
                        else
                        {
                            votosnulos++;
                        }
                    }
                    else
                    {
                        votosnulos++;
                    }
                }
            }
            int votosMaior = votos[0];
            for (int i = 0; i < votos.Length; i++)
            {
                if (votos[i] > votosMaior)
                {
                    maisVotado = i;
                    votosMaior = votos[i];
                }
            }
            int votosMenor = votos[0];
            for (int i = 0; i < votos.Length; i++)
            {
                if (votos[i] < votosMenor)
                {
                    menosVotado = i;
                    votosMenor = votos[i];
                }
            }
            Console.WriteLine($"O mais votado é {candidatos[maisVotado]} com {votosMaior}");
            Console.WriteLine($"O menos votado é o {candidatos[menosVotado]} com {votosMenor}");
            Console.WriteLine($"Tem {votosnulos} Votos nulos");
            
        }
    }
}
