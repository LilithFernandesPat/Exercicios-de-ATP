﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string palavra, palavrareverso = string.Empty;
            Console.Write("Qual a palavra? ");
            palavra = Console.ReadLine();
          
            for (int i = palavra.Length-1, j=0; i >= 0; i--)
            {
                palavrareverso += palavra[i];
            }
            if(palavrareverso == palavra)
            {
                Console.WriteLine("É um Palindromo");
            }
            Console.ReadKey();
        }
    }
}
