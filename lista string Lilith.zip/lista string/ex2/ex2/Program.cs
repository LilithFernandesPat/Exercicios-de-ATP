﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string senha;
            Console.WriteLine("Digite sua senha");
            senha = Console.ReadLine();
            string senharetorno = criptografar(senha);
            Console.WriteLine(senharetorno);
        }
        static string criptografar(string senha)
        {
            char[] senhacripto = new char[senha.Length];
            senhacripto = senha.ToCharArray();
            for (int i = 0; i < senha.Length; i++)
            {
                if (senha[i] == 'a' || senha[i] == 'e' || senha[i] == 'i' || senha[i] == 'o' || senha[i] == 'u')
                {
                    senhacripto[i] = '*';
                }
            }
            string senharetorno = new string(senhacripto);
            return senharetorno;        
        }
    }

}
