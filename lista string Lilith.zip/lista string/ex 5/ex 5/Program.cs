﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string verbo, conjulga;
            do
            {
                Console.WriteLine("Digite o verbo terminado em ar (ex: andar) ");
                verbo = Console.ReadLine();
                verbo = verbo.ToLower();
            } while (!verbo.EndsWith("ar"));
            conjulga = verbo.Substring(0, verbo.Length -2);
            //Conjulgação
            Console.WriteLine($"Eu {conjulga}o\r\nTu {conjulga}as\r\nEle {conjulga}a\r\n" +
                $"Nós {conjulga}amos\r\nVós {conjulga}ais\r\nEles {conjulga}am");
            Console.ReadKey();
        }
    }
}
