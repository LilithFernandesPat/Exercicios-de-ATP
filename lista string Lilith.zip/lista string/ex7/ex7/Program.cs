﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Faça um programa que permita que o usuário informe, via teclado, o nome e a idade de diversas
            pessoas. Crie um arquivo com essas informações. O programa deverá ler as informações até que seja
            informado um valor negativo para a idade. Depois abra novamente o arquivo, leia e imprima na tela
            todas as informações do arquivo*/
            string nome = null;
            int idade = 0;
            string path = "arquivo.txt";
            char escolha;
            Console.WriteLine("Deseja sobrescrever o arquivo? digite 'S'");
            escolha = char.Parse(Console.ReadLine());
            switch (escolha)
            {
                case 'S':
                    StreamWriter st = new StreamWriter(path);
                    st.Close();
                    break;
            }
            using (StreamWriter st = File.AppendText(path))
            {
                while (idade >= 0)
                {
                    Console.WriteLine("Digite o nome e a idade (Digite um valor negativo para a idade para finalizar");
                    nome = Console.ReadLine();
                    idade = int.Parse(Console.ReadLine());
                    st.WriteLine($"Nome: {nome}, Idade: {idade}");
                }
            }
            StreamReader sl = new StreamReader(path);
            using (sl = File.OpenText(path))
            {
                String s = " ";

                while ((s = sl.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }
        }
    }
}
