﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path1 = "arquivo1.txt", path2 = "arquivo2.txt", path3 = "arquivo3.txt";
            
            using (StreamWriter arq1 = File.AppendText(path1))
            {
                Console.WriteLine("Escreva no Arquivo 1");
                string texto = Console.ReadLine();
                arq1.WriteLine(texto);
            }
            using (StreamWriter arq2 = File.AppendText(path2))
            {
                Console.WriteLine("Escreva no Arquivo 2");
                string texto = Console.ReadLine();
                arq2.WriteLine(texto);
            }
            using (StreamWriter arq3 = File.AppendText(path3))
            {
                using (StreamReader arq1r = File.OpenText(path1))
                {
                    arq3.WriteLine(arq1r.ReadToEnd());
                }
                using (StreamReader arq2r = File.OpenText(path2))
                {
                    arq3.WriteLine(arq2r.ReadToEnd());
                }
            }
            StreamReader arq3r;
            string s = " ";
            using (arq3r = File.OpenText(path3))
            {
                while ((s = arq3r.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }
        }
    }
}
