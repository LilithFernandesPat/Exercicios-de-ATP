﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Faça um programa que leia uma frase, calcule e mostre a quantidade de palavras da frase
            Console.WriteLine("Insira sua frase");
            string frase = Console.ReadLine();
            int contador=0;
            for(int i = 0; i < frase.Length; i++)
            {
                if (frase[i] == ' ')
                {
                    contador++;
                }   
            }
            Console.WriteLine($"Tem {contador + 1} palavras na frase");
            Console.ReadKey();
        }
    }
}
