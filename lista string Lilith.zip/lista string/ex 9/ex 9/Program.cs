﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = "Listacompras.txt";
            double total = 0, custo = 0;
            using (StreamReader sr = File.OpenText(path))
            {
                string s;
                while ((s = sr.ReadLine()) !=  null)
                {
                    string[] separador = s.Split(';');
                    string produto = separador[0];
                    double quantidade = double.Parse(separador[1]);
                    double valorProduto = double.Parse(separador[2]);
                    custo = quantidade * valorProduto;
                    total += custo;
                    Console.WriteLine($"{produto}: {custo}");
                }
                Console.WriteLine($"valor total: {total}");
                
                
            }
        }
    }
}
