﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escreva a Palavra");
            string palavra = Console.ReadLine();
            invertida(palavra);
           
        }
        static void invertida(string palavra)
        {
            for (int i = palavra.Length - 1; i >= 0; i--)
            {
                Console.Write($"{palavra[i]}");
               
            }
            Console.WriteLine("");
        }
    }
}
